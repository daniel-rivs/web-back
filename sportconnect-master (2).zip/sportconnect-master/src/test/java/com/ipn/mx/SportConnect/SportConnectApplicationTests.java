package com.ipn.mx.SportConnect;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SportConnectApplicationTests {

	@Test
	void contextLoads() {
	}

}
